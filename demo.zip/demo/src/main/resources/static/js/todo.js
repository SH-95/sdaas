// Todo リストを取得して表示
function loadTodos() {
    fetch('/api/todos')
        .then(response => response.json())
        .then(todos => {
            const todoList = document.getElementById('todoList');
            todoList.innerHTML = '';
            todos.forEach(todo => {
                const div = document.createElement('div');
                div.className = `todo-item ${todo.completed ? 'completed' : ''}`;
                div.innerHTML = `
                    <input type="checkbox" ${todo.completed ? 'checked' : ''} 
                        onchange="toggleTodo(${todo.id}, this.checked)">
                    <div style="flex-grow: 1; margin: 0 10px;">
                        <h3>${todo.title}</h3>
                        <p>${todo.content}</p>
                    </div>
                    <button onclick="deleteTodo(${todo.id})">削除</button>
                `;
                todoList.appendChild(div);
            });
        });
}

// 新しいTodoを作成
function createTodo() {
    const title = document.getElementById('todoTitle').value;
    const content = document.getElementById('todoContent').value;
    
    fetch('/api/todos', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            title: title,
            content: content,
            completed: false
        })
    })
    .then(response => response.json())
    .then(() => {
        document.getElementById('todoTitle').value = '';
        document.getElementById('todoContent').value = '';
        loadTodos();
    });
}

// Todoの完了状態を切り替え
function toggleTodo(id, completed) {
    fetch(`/api/todos/${id}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            completed: completed
        })
    })
    .then(() => loadTodos());
}

// Todoを削除
function deleteTodo(id) {
    if (confirm('本当に削除しますか？')) {
        fetch(`/api/todos/${id}`, {
            method: 'DELETE'
        })
        .then(() => loadTodos());
    }
}

// 페이지 로드 시 Todo 리스트 표시
document.addEventListener('DOMContentLoaded', loadTodos); 